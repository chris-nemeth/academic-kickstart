#This file contains code for using the gradient ascent algorithm.
########################################################################
# Scalar Linear Gaussian State Space Model 
#
# X_1 ~ N(0,sigma2/(1-phi^2))
# X_n+1 ~ phi*X_n + sigma*V_n
# Y_n ~ X_n + tau*W_n
#
#################################################################
rm(list=ls())
source("data_generation.R")   #Simulate date
source("Our_algorithm.R") #Load particle filter code. This can be replaced with Fixed-lag and O(N^2), but note that you need to change the arguments in PF(...)
######################################################################
#Batch Parameter Estimation

#note that T is the length of the data

N     = 2000               #Number of particles
NumIt = 1000               #Number of iterations
parEst = matrix(0,NumIt,3)

theta = c(0.6,1,0.7) #starting value
parEst[1,] = theta

for(k in 2:NumIt){
G2 =  PF(y,theta,N,0.95)
if(all(diag(solve(G2$hess))>0)){ #simple check of matrix stability
 par = theta + (k-1)^(-2/3)*solve(G2$hess)%*%G2$score
 }else{
 par = theta + (k-1)^(-2/3)*G2$score/T}
#parameter constraints (Note: you could alternatively reparameterise, e.g. log(sigma))
if(par[1]>0 && par[1]<1) theta[1]=par[1]
if(par[2]>0) theta[2] = par[2]
if(par[3]>0) theta[3] =par[3]
parEst[k,] = theta                        #Store parameter estimate
cat("It:",k,"\n")
print(parEst[k,])
}
