#This file contains the code to execute a particle filter to calculate the score using the Poyiadjis O(N^2) algorithm  
#########################################################
# Scalar Linear Gaussian State Space Model 
#
# X_1 ~ N(0,sigma2/(1-phi^2))
# X_n+1 ~ phi*X_n + sigma*V_n
# Y_n ~ X_n + tau*W_n
#
#################################################################
PF = function(y,theta,N){
    # y - data
    # theta - model parameters
    # N - number of particles
  itime  = proc.time()[3]                               #Start time
  phi = theta[1]; sigma = theta[2]; tau = theta[3]
  T  = length(y)
  X =  rnorm(N,0,sqrt((sigma^2)/(1-phi^2)))              #Initialise
  Alphas = matrix(0,nrow=3,ncol=N)                       #dlogP(x_n,y_1:n)
  Sn = matrix(0,nrow=T,ncol=3)                          #dlogP(y_1:n)
  Betas = array(0,dim=c(N,3,3))                         # dlog2(p(x_1:T,y_1:T))
  Sigma = array(0,dim=c(T,3,3))                        # -dlog2(p(y_1:T))
  Alphas[1,]  = -phi/(1-phi^2) + phi*(X/sigma)^2  
  Alphas[2,]  = -1/sigma + (1-phi^2)*X^2/sigma^3
  Betas[,1,1] = (X/sigma)^2-1/(1-phi^2)-2*phi^2/(1-phi^2)^2
  Betas[,1,2] = -2*phi*X^2/sigma^3
  Betas[,2,1] = Betas[,1,2]
  Betas[,2,2] = 1/(sigma)^2 - 3*X^2*(1-phi^2)/(sigma^4)
	Sn[1,] = apply(Alphas,1,mean)
  Sigma[1,,] = -cov(t(Alphas)) -  apply(Betas,2:3,mean)
   for (t in 2:T){
    # Resampling
  w0 = dnorm(y[t],phi*X,sqrt(sigma^2+tau^2),log=TRUE)  # q(y_t|x_t-1)
  weights     = exp(w0-max(w0))
  k           = sample(1:N,size=N,replace=T,prob=weights)   #Resample
  X1          = X
  omega2      = 1/(1/sigma^2+1/tau^2)
  mu          = omega2*(y[t]/tau^2+phi*X1[k]/sigma^2)
  X           = rnorm(N,mu,sqrt(omega2))

    #Calculate w[t]f_theta(X[t]|X[t-1])
    xtemp=rep(X,N);x1temp=rep(phi*X1,N)
    wf=matrix(X,nr=N,nc=N,byrow=F)-matrix(phi*X1,nr=N,nc=N,byrow=T) 
    wf=exp(-0.5*wf^2/sigma^2)/sqrt(2*pi*sigma^2)
    sum_f=apply(wf,1,sum) 
    
    # Estimate the joint score 
    Alphas.n = Alphas ##concern over updating alpha whilst running the recursions
    Alphas.n[1,] = sapply(1:N, function(i) sum(wf[i,]*(Alphas[1,]+ (X1/sigma^2)*(X[i]-phi*X1)))/sum_f[i]) 
    Alphas.n[2,] = sapply(1:N, function(i) sum(wf[i,]*(Alphas[2,] -1/sigma + (X[i]-phi*X1)^2/sigma^3))/sum_f[i])
    Alphas.n[3,] = sapply(1:N, function(i)  sum(wf[i,]*(Alphas[3,] -1/tau + (1/tau^3)*(y[t]-X[i])^2))/sum_f[i]) 
   
    #Estimate observed information of joint dist
    Betas.n = Betas
    Betas.n[,1,1] = sapply(1:N, function(i) sum(wf[i,]/sum_f[i]*((Alphas[1,]+ (X1/sigma^2)*(X[i]-phi*X1))^2+(Betas[,1,1]-(X1/sigma)^2)))- Alphas.n[1,i]%*%t(Alphas.n[1,i]))
    Betas.n[,1,2] = sapply(1:N, function(i) sum(wf[i,]/sum_f[i]*((Betas[,1,2]-(2*X1/(sigma^3))*(X[i]-phi*X1))+(Alphas[1,]+ (X1/sigma^2)*(X[i]-phi*X1))*(Alphas[2,] -1/sigma + (X[i]-phi*X1)^2/sigma^3)))- Alphas.n[1,i]%*%t(Alphas.n[2,i]))
    Betas.n[,2,1] = Betas.n[,1,2]
    Betas.n[,1,3] = sapply(1:N, function(i) sum(wf[i,]/sum_f[i]*((Alphas[1,]+ (X1/sigma^2)*(X[i]-phi*X1))*(Alphas[3,] -1/tau + (1/tau^3)*(y[t]-X[i])^2)))- Alphas.n[1,i]%*%t(Alphas.n[3,i]))
    Betas.n[,3,1] = Betas.n[,1,3]
    Betas.n[,2,2] = sapply(1:N, function(i) sum(wf[i,]/sum_f[i]*((Betas[,2,2] + 1/sigma^2 -3*(X[i]-phi*X1)^2/(sigma^4))+(Alphas[2,] -1/sigma + (X[i]-phi*X1)^2/sigma^3)^2))-Alphas.n[2,i]%*%t(Alphas.n[2,i]))
    Betas.n[,2,3] = sapply(1:N, function(i) sum(wf[i,]/sum_f[i]*((Alphas[2,] -1/sigma + (X[i]-phi*X1)^2/sigma^3)*(Alphas[3,] -1/tau + (1/tau^3)*(y[t]-X[i])^2)))- Alphas.n[2,i]%*%t(Alphas.n[3,i]))
    Betas.n[,3,2] = Betas.n[,2,3]
    Betas.n[,3,3] = sapply(1:N, function(i) sum(wf[i,]/sum_f[i]*((Betas[,3,3] + 1/tau^2 - 3*(y[t]-X[i])^2/(tau^4))+(Alphas[3,] -1/tau + (1/tau^3)*(y[t]-X[i])^2)^2)) - Alphas.n[3,i]%*%t(Alphas.n[3,i]))
    Alphas = Alphas.n
    Betas = Betas.n
            #Score estimate
	Sn[t,] = apply(Alphas,1,mean)

    ########################
    #Hessian
Sigma[t,,] = -cov(t(Alphas)) -  apply(Betas,2:3,mean)

  }
       
      ctime = proc.time()[3]  #End time
  cat(" Total time elapsed: ", round((ctime-itime)/60,2),"\n") #Print run time
    return(list(score=Sn[T,],hess=Sigma[T,,])) 
}
####################################################################################
