#This file contains code for the generation of data from a scalar Linear Gaussian State Space Model 
#
# X_1 ~ N(0,sigma2/(1-phi^2))
# X_n+1 ~ phi*X_n + sigma*V_n
# Y_n ~ X_n + tau*W_n
#
# where V_n & W_n ~ N(0,1)
#
#    tau2       ~ IG(a0,A0)
#    beta|sigma2  ~ N(b0[2],sigma2*B0[2])
#    sigma2       ~ IG(nu0/2,nu0*sigma20/2)
###############################################
#Generate data

T = 1000   #Length of data
x = vector(length=T)    #latent process
y = vector(length=T)    #observations

phi = 0.9
sigma = 0.7
tau = 1

x[1] = rnorm(1,0,sqrt((sigma^2)/(1-phi^2))) #Sample from stationary distribution

for(t in 2:T){
 x[t] = rnorm(1,phi*x[t-1],sigma)
}
 y = rnorm(T,x,tau)
