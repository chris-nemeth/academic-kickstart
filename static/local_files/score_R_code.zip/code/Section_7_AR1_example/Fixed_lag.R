#This file contains the code to execute a particle filter to calculate the score using the fixed lag smoother
#########################################################
# Scalar Linear Gaussian State Space Model 
#
# X_1 ~ N(0,sigma2/(1-phi^2))
# X_n+1 ~ phi*X_n + sigma*V_n
# Y_n ~ X_n + tau*W_n
#
##########################################################################
PF = function(y,theta,N,L){
    # y - data
    # theta - model parameters
    # N - number of particles
    # L - lag length
  itime  = proc.time()[3]                               #Start time
  phi = theta[1]; sigma = theta[2]; tau = theta[3]
  T  = length(y)                                        #Time
  omega2      = 1/((1-phi^2)/sigma^2+1/tau^2)
  mu          = omega2*(y[1]/tau^2)
  X = matrix(0,T,N)                                     #Store all particles
  a = matrix(0,T,N)                                     #Store indices
  X[1,] =  rnorm(N,mu,sqrt(omega2))                     #Initialise
  Sn = matrix(0,nrow=T,ncol=3)                          # dlog(p(y_1:T))
  Alphas = matrix(0,nrow=3,ncol=N)                      # dlog(p(x_1:T,y_1:T))
  alphas = array(0,dim=c(L,3,N))                        # for tracking the cross terms
  Betas = matrix(0,3,3)                                 # dlog2(p(x_1:T,y_1:T))
   #Run the filter
    for (t in 2:T){
    # Resampling
    w0        = dnorm(y[t],phi*X[t-1,],sqrt(sigma^2+tau^2))  # q(y_t|x_t-1)
    a[t,]     = sample(1:N,size=N,replace=T,prob=w0)   #Resample
     # Propagating states
    omega2    = 1/(1/sigma^2+1/tau^2)
    mu        = omega2*(y[t]/tau^2+phi*X[t-1,a[t,]]/sigma^2)
    X[t,]     = rnorm(N,mu,sqrt(omega2))
  }
  #Run the smoother
  for(t in 1:T){      #Sample the ancestors
    at = 1:N
    kk = min(t+L,T)
  for(ll in kk:t){
    att = at
    at = a[ll,att]
  }
   if(t==1){
       #Alphas
      Alphas[1,] = -phi/(1-phi^2) + phi*(X[1,att]/sigma)^2
      Alphas[2,] = -1/sigma + (1-phi^2)*X[1,att]^2/sigma^3
      Alphas[3,] = -1/tau + (1/tau^3)*(y[1]-X[1,att])^2
      # Estimate the score
     Sn[1,] = rowMeans(Alphas)

    #2nd derivatives
   Betas[1,1] = mean(((X[1,att]/sigma)^2-1/(1-phi^2)-2*phi^2/(1-phi^2)^2))
   Betas[1,2] = mean((-2*phi*X[1,att]^2/sigma^3))
   Betas[2,1] = Betas[1,2]
   Betas[2,2] = mean((1/(sigma)^2 - 3*X[1,att]^2*(1-phi^2)/(sigma^4)))

    }else{ 
    #Alphas
    Alphas[1,] = ((X[t-1,at]/sigma^2)*(X[t,att]-phi*X[t-1,at]))
    Alphas[2,] = ((-1/sigma + (1/sigma^3)*(X[t,att]-phi*X[t-1,at])^2))
    Alphas[3,] = ((-1/tau + (1/tau^3)*(y[t]-X[t,att])^2))
    # Estimate the score 
   Sn[t,] =  Sn[t-1,] + rowMeans(Alphas)

    #2nd derivatives
   Betas[1,1] = Betas[1,1] + mean((-(X[t-1,at]/sigma)^2))
   Betas[1,2] = Betas[1,2] + mean((-(2*X[t-1,at]/(sigma^3))*(X[t,att]-phi*X[t-1,at])))
   Betas[2,1] = Betas[1,2]
   Betas[2,2] = Betas[2,2] + mean((1/sigma^2 -3*(X[t,att]-phi*X[t-1,at])^2/(sigma^4)))
   Betas[3,3] = Betas[3,3] + mean((1/tau^2 - 3*(y[t]-X[t,att])^2/(tau^4)))
  }
  }
##########################
#####Calculate the cross terms for alpha
#############################
    j=1
  for(t in (T-L+1):T){ #Sample the ancestors
    at = 1:N
    kk = min(t+L,T)
  for(ll in kk:t){
    att = at
    at = a[ll,att]
  }
    #Store all of the 1st order derivatives from T to T-L+1
   alphas[j,1,] = ((X[t-1,at]/sigma^2)*(X[t,att]-phi*X[t-1,at]))
   alphas[j,2,] = ((-1/sigma + (1/sigma^3)*(X[t,att]-phi*X[t-1,at])^2))
   alphas[j,3,] = ((-1/tau + (1/tau^3)*(y[t]-X[t,att])^2))
  j = j+1
  }
      alphas = apply(alphas,2:3,sum) + Sn[T-L,]   #Sum the lagged estimates + average of everything before the lag
     Sn2 = (1/N)*alphas%*%t(alphas)               #Cross terms

     Sigma= Sn[T,]%*%t(Sn[T,]) - (Sn2 + Betas)   #Information matrix 
      ctime = proc.time()[3]  #End time
  cat(" Total time elapsed: ", round((ctime-itime)/60,2),"\n") #Print run time
    return(list(score=Sn[T,],hess=Sigma))
}
##########################################################################
