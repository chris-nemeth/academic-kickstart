#This file contains the code to execute a particle filter to calculate the score using the Kalman filter
#########################################################
# Scalar Linear Gaussian State Space Model 
#
# X_1 ~ N(0,sigma2/(1-phi^2))
# X_n+1 ~ phi*X_n + sigma*V_n
# Y_n ~ X_n + tau*W_n
#
#################################################################
library(numDeriv);

Kal.Fil = function(Y,phi,sigma,tau){

 itime  = proc.time()[3]            #Start time
T  = length(Y)                      # Run length

lik=function(theta){
T=length(Y)
xm = matrix(0,nrow=1,ncol=T)        #predicted mean
xp = matrix(0,nrow=1,ncol=T)        #posterior mean
Pp = rep(0,T)                       #posterior covariance
Pm = rep(0,T)                       #predicted covariance
F <- theta[1]                              #state update
G <- 1                                 #measurement update
Q <- theta[2]^2                            #process noise covariance
R <- theta[3]^2                              #measurement noise covariance
m0 = 0
C <- theta[2]^2/(1-theta[1]^2)                  #x[1] ~ N(x0,C).       
I <- 1                                 #identity matrix

# The Kalman filter recursions:

# Initialise the correction and prediction phases at t=1

xm[,1] = F%*%m0
Pm[1]  = F%*%C%*%t(F) + Q                    # Prediction
K = C%*%t(G)%*%solve(G%*%C%*%t(G) + R)       # The Kalman Gain
xp[,1] = xm[,1] + K%*%(Y[1] - G%*%xm[,1])    # Correction
Pp[1] = (I - K%*%G)%*%C                      # The posterior error covariance
if(T>1){
for(t in 2: T)            #Run the filter
{

# Prediction
xm[,t] = F%*%xp[,t-1]                 #Project the state ahead
Pm[t] = F%*%Pp[t-1]%*%t(F) + Q        #Project error covariance ahead

# Correction
K = Pm[t]%*%t(G)%*%solve(G%*%Pm[t]%*%t(G) + R)  #Kalman gain
xp[,t] = xm[,t] + K%*%(Y[t] - G%*%xm[,t])    #Update estimate with measurement Y[t] 
Pp[t] = (I - K%*%G)%*%Pm[t]                        #Update error covariance
}
}
ll=sum(dnorm(Y,xm,sqrt(Pm + R),log=T ) ) ##sum log p(y_t|y_{1:t-1}) Y_t=X_t+error so Y_t|y_{1:t-1} ~ N(E(X_t|y_{1:t-1}), Var(X_t|y_{1:t-1})+R)
return(ll)
}
grad=jacobian(func=lik,x=c(phi,sigma,tau))
hess = hessian(func=lik,x=c(phi,sigma,tau))
      ctime = proc.time()[3]  #End time
  cat(" Total time elapsed: ", round((ctime-itime)/60,2),"\n") #Print run time

return(list(grad=grad,hess=-hess))
}
