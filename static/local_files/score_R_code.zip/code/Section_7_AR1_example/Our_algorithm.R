#This file contains the code to execute a particle filter to calculate the score using our algorithm (Alg. 2 from the paper).
#########################################################
# Scalar Linear Gaussian State Space Model 
#
# X_1 ~ N(0,sigma2/(1-phi^2))
# X_n+1 ~ phi*X_n + sigma*V_n
# Y_n ~ X_n + tau*W_n
#
#################################################################
PF = function(y,pars,N,lambda=0.95){
    # y - data
    # pars - model parameters
    # N - number of particles
    # lambda - shrinkage parameter
  itime  = proc.time()[3]                               #Start time
  phi = pars[1]; sigma = pars[2]; tau = pars[3]
  h2 = 1-lambda^2
  T  = length(y)                                        #Time
  omega2      = 1/((1-phi^2)/sigma^2+1/tau^2)
  mu          = omega2*(y[1]/tau^2)
  X           = rnorm(N,mu,sqrt(omega2))                #Sample from prior
  w1 =  dnorm(y[1],X,tau)                               # Weight
  w1 = w1/sum(w1)                                        #Normalise weights
  Alphas = matrix(0,nrow=3,ncol=N)                       # dlog(p(x_1:T,y_1:T))
  Sn = matrix(0,nrow=T,ncol=3)                          # dlog(p(y_1:T))
  Betas = array(0,dim=c(N,3,3))                          # dlog2(p(x_1:T,y_1:T))
  nu2=matrix(0,3,3)                                      #Track covariance of alpha
  Sigma = array(0,dim=c(T,3,3))                          # -dlog2(p(y_1:T))
  Alphas[1,] = -phi/(1-phi^2) + phi*(X/sigma)^2  
  Alphas[2,] = -1/sigma + (1-phi^2)*X^2/sigma^3
  Alphas[3,] = -1/tau + (1/tau^3)*(y[1]-X)^2
   Sn[1,] = w1%*%t(Alphas)
  Betas[,1,1] = (X/sigma)^2-1/(1-phi^2)-2*phi^2/(1-phi^2)^2
  Betas[,1,2] = -2*phi*X^2/sigma^3
  Betas[,2,1] = Betas[,1,2]
  Betas[,2,2] = 1/(sigma)^2 - 3*X^2*(1-phi^2)/(sigma^4)
    covalpha = cov(t(Alphas))
        mbeta  =  apply(Betas,2:3,mean)
nu2=nu2+covalpha
    logl = log(mean(dnorm(y[1],phi*X,sqrt(sigma^2+tau^2))))        #log-likelihood
    for (t in 2:T){
         # Resampling
    w0          = dnorm(y[t],phi*X,sqrt(sigma^2+tau^2))  # q(y_t|x_t-1)
    logl       = logl + log(mean(w0))
    k           = sample(1:N,size=N,replace=T,prob=w0)   #Resample
    X1          = X[k]                                      
    Alphas      = Alphas[,k]
    Betas       = Betas[k,,]
      # Propagating states
    omega2    = 1/(1/sigma^2+1/tau^2)  
    mu        = omega2*(y[t]/tau^2+phi*X1/sigma^2) 
    X         = rnorm(N,mu,sqrt(omega2))                     #q(x_t|x_t-1,y_t)
  
    # Estimate the joint score 
    Alphas[1,] = lambda*Alphas[1,] + (1-lambda)*Sn[t-1,1] + (X1/sigma^2)*(X-phi*X1) 
    Alphas[2,] = lambda*Alphas[2,] + (1-lambda)*Sn[t-1,2] + -1/sigma + (1/sigma^3)*(X-phi*X1)^2 
    Alphas[3,] = lambda*Alphas[3,] + (1-lambda)*Sn[t-1,3] + -1/tau + (1/tau^3)*(y[t]-X)^2

    #Estimate observed information of joint dist
    Betas[,1,1] = lambda*Betas[,1,1] + (1-lambda)*mbeta[1,1] - (X1/sigma)^2 
    Betas[,1,2] = lambda*Betas[,1,2] + (1-lambda)*mbeta[1,2] - (2*X1/(sigma^3))*(X-phi*X1)
    Betas[,2,1] = Betas[,1,2]
    Betas[,2,2] = lambda*Betas[,2,2] + (1-lambda)*mbeta[2,2] + 1/sigma^2 -3*(X-phi*X1)^2/(sigma^4)
    Betas[,3,3] = lambda*Betas[,3,3] + (1-lambda)*mbeta[3,3] + 1/tau^2 - 3*(y[t]-X)^2/(tau^4)

    #Estimate the score
    Sn[t,] = w1%*%t(Alphas)
    #Estimate the information matrix
        covalpha = cov(t(Alphas))
        mbeta  =  apply(Betas,2:3,mean)
     Sigma[t,,] = -covalpha  -  mbeta - h2*nu2
      nu2=nu2+covalpha
  }
      ctime = proc.time()[3]  #End time
  cat(" Total time elapsed: ", round((ctime-itime)/60,2),"\n") #Print run time
    return(list(score=Sn[T,],hess=Sigma[T,,]))
}
######################################################################
