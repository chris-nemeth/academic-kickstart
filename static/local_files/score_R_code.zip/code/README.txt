This folder contains the code used to produce the results in the paper. In this folder you will find two folders: "Section_7_AR1_example" and "Section_7_Polio_example" which contain the code for the respective examples. 

The code is written in R, however there are C functions available for the AR1 example which can be provided if requested. For the polio example, the R package "acp" is required for the polio counts data.

The Poyiadjis (2011) O(N) algorithm can be executed from "Our_algorithm.R" by setting lambda=1.

The code for the comparisons in Section 6 is the same as for Section 7.1 and can be recreated using the code from "Section_7_AR1_example". 

In each folder there is a file titled "Gradient_ascent_algorithm.R". This file calls the chosen particle filter and executes the steepest ascent algorithm. 

If there are any mistakes in the code then please free to contact me at c.nemeth@lancaster.ac.uk
