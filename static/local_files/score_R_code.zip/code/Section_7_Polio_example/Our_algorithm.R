#This file contains the code for parameter estimation using the example from Section 7.2 of the paper.
# Our algorithm (Alg. 2 in the paper) is used to estimate the score
#######################################################################
# Nonlinear seasonal Poisson SSM
#
# X_1 ~ N(0,sigma2/(1-phi^2))
# X_n+1 = phi*X_n + sigma*V_n
# beta_n = mu1+mu2*(t/1000)+mu3*cos(2*pi*t/12)+mu4*sin(2*pi*t/12)+mu5*cos(2*pi*t/6)+mu6*sin(2*pi*t/6)
# Y_n = Pois(beta_n*exp(X_n))
#
#############################################################
PF = function(Y,theta,N,lambda=0.95){
    #Y is the data
    #theta is a vector of model parameters
    #N is the number of particles
    #lambda is the shrinkage parameter as specified in the paper
    
    itime  = proc.time()[3]                               #Start time
    mu1 = theta[1];  mu2 = theta[2]; mu3 = theta[3]; mu4 = theta[4]; mu5 = theta[5]; mu6 = theta[6]; phi = theta[7];  sigma = theta[8];
    T  = length(Y)                                        #Time
    X  =  rnorm(N,0,sqrt(sigma^2/(1-phi^2)))              #Initialise particles from stationary distribution
    beta = mu1 + mu2*(1/1000) + mu3*cos(2*pi/12) + mu4*sin(2*pi/12) + mu5*cos(2*pi/6)+mu6*sin(2*pi/6) #seasonal component
    w1 = dpois(Y[1],exp(beta+X))
    logl = log(mean(w1))
    w1 = w1/sum(w1)
   alphas = matrix(0,nrow=8,ncol=N)                       # dlog(p(x_1:T,y_1:T))
  Sn = matrix(0,nrow=T,ncol=8)                          # dlog(p(y_1:T))
    alphas[1,] = Y[1]-exp(beta+X)
    alphas[2,] = (1/1000)*(Y[1]-exp(beta+X))
    alphas[3,] = cos(2*pi*1/12)*(Y[1]-exp(beta+X))
    alphas[4,] = sin(2*pi*1/12)*(Y[1]-exp(beta+X))
    alphas[5,] = cos(2*pi*1/6)*(Y[1]-exp(beta+X))
    alphas[6,] = sin(2*pi*1/6)*(Y[1]-exp(beta+X))
    alphas[7,] = (X^2*phi/sigma^2-phi/(1-phi^2))
    alphas[8,] = ((X^2)*(1-phi^2)/sigma^3-1/sigma)
    Sn[1,] = w1%*%t(alphas)                                      #Estimate the score at t=1
    for (t in 2:T){
        #Apply bootstrap filter
    # Resampling
    k           = sample(1:N,size=N,replace=T,prob=w1)   #Resample
    X1          = X[k]
    alphas      = alphas[,k]
    # Propagating states
    X = rnorm(N,phi*X1,sigma)
    beta = mu1 + mu2*(t/1000) + mu3*cos(2*pi*t/12) + mu4*sin(2*pi*t/12) + mu5*cos(2*pi*t/6) + mu6*sin(2*pi*t/6)
    w1       = dpois(Y[t],exp(beta+X))   #p(y_t|x_t)
    logl     = logl + log(mean(w1))                         #Log-likelihood estimate
    w1       = w1/sum(w1)                                   #Normalise weights
    #Estimate the gradient of joint distribution
    alphas[1,] = lambda*alphas[1,] + (1-lambda)*Sn[t-1,1] + Y[t]-exp(beta+X)
    alphas[2,] = lambda*alphas[2,] + (1-lambda)*Sn[t-1,2] + (t/1000)*(Y[t]-exp(beta+X))
    alphas[3,] = lambda*alphas[3,] + (1-lambda)*Sn[t-1,3] + cos(2*pi*t/12)*(Y[t]-exp(beta+X))
    alphas[4,] = lambda*alphas[4,] + (1-lambda)*Sn[t-1,4] + sin(2*pi*t/12)*(Y[t]-exp(beta+X))
    alphas[5,] = lambda*alphas[5,] + (1-lambda)*Sn[t-1,5] + cos(2*pi*t/6)*(Y[t]-exp(beta+X))
    alphas[6,] = lambda*alphas[6,] + (1-lambda)*Sn[t-1,6] + sin(2*pi*t/6)*(Y[t]-exp(beta+X))
    alphas[7,] = lambda*alphas[7,] + (1-lambda)*Sn[t-1,7] + (X1/sigma^2)*(X-phi*X1)
    alphas[8,] = lambda*alphas[8,] + (1-lambda)*Sn[t-1,8] + (-1/sigma + (1/sigma^3)*(X-phi*X1)^2)
    
    Sn[t,] = w1%*%t(alphas)        #Score estimate at time t
  }
      ctime = proc.time()[3]  #End time
  cat(" Total time elapsed: ", round((ctime-itime)/60,2),"\n") #Print run time
    return(list(logl=logl,score=Sn[T,]))
}

#################################################################
