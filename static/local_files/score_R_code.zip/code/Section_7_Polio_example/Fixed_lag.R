#This file contains the code for parameter estimation using the example from Section 7.2 of the paper.
# The fixed-lag smoother is used to estimate the score
##############################################################################
# Nonlinear seasonal Poisson SSM
#
# X_1 ~ N(0,sigma2/(1-phi^2))
# X_n+1 = phi*X_n + sigma*V_n
# beta_n = mu1+mu2*(t/1000)+mu3*cos(2*pi*t/12)+mu4*sin(2*pi*t/12)+mu5*cos(2*pi*t/6)+mu6*sin(2*pi*t/6)
# Y_n = Pois(beta_n*exp(X_n))
#
#############################################################
#Fixed-lag particle filter is used to estimate the score

PF = function(Y,theta,N,L){
    #Y is the data
    #theta is a vector of model parameters
    #N is the number of particles
    #L is the pre-specified lag

    itime  = proc.time()[3]                               #Start time
    mu1 = theta[1];  mu2 = theta[2]; mu3 = theta[3]; mu4 = theta[4]; mu5 = theta[5]; mu6 = theta[6]; phi = theta[7];  sigma = theta[8];
    T  = length(Y)                                        #Time
    X = matrix(0,T,N)                                     #Store all particles
    a = matrix(0,T,N)                                     #Store indices
    a[1,] = 1:N
    weights = matrix(0,T,N)                                     #weights
    X[1,]  =  rnorm(N,0,sqrt(sigma^2/(1-phi^2)))         #Initialise particles from stationary distribution
    beta = rep(0,T)                                     # store seasonal components
    beta[1] = mu1 + mu2*(1/1000) + mu3*cos(2*pi/12) + mu4*sin(2*pi/12) + mu5*cos(2*pi/6)+mu6*sin(2*pi/6)
    weights[1,] = dpois(Y[1],exp(beta[1]+X[1,]))
    logl = log(mean(weights[1,]))
    weights[1,] = weights[1,]/sum(weights[1,])
   alphas = matrix(0,nrow=8,ncol=N)                       # dlog(p(x_1:T,y_1:T))
   Sn = matrix(0,nrow=T,ncol=8)                          # dlog(p(y_1:T))
    for (t in 2:T){
        #Run bootstrap particle filter
     # Resampling
    a[t,]  = sample(1:N,size=N,replace=T,prob=weights[t-1,])   #Resample
    X[t,]  = rnorm(N,phi*X[t-1,a[t,]],sigma)                   #Propagate
    beta[t] = mu1 + mu2*(t/1000) + mu3*cos(2*pi*t/12) + mu4*sin(2*pi*t/12) + mu5*cos(2*pi*t/6) + mu6*sin(2*pi*t/6)
    weights[t,] = dpois(Y[t],exp(beta[t]+X[t,]))   #p(y_t|x_t)
    logl     = logl + log(mean(weights[t,]))
    weights[t,]       = weights[t,]/sum(weights[t,])                                   #Normalise weights
}
      #Run the smoother
  for(t in 2:T){
    at = 1:N
    kk = min(t+L,T)
  for(ll in kk:t){
    att = at
    at = a[ll,att]
  }
        #Estimate the gradient of joint distribution
    alphas[1,] = Y[t]-exp(beta[t]+X[t,att])
    alphas[2,] = (t/1000)*(Y[t]-exp(beta[t]+X[t,att]))
    alphas[3,] = cos(2*pi*t/12)*(Y[t]-exp(beta[t]+X[t,att]))
    alphas[4,] = sin(2*pi*t/12)*(Y[t]-exp(beta[t]+X[t,att]))
    alphas[5,] = cos(2*pi*t/6)*(Y[t]-exp(beta[t]+X[t,att]))
    alphas[6,] = sin(2*pi*t/6)*(Y[t]-exp(beta[t]+X[t,att]))
    alphas[7,] = (X[t-1,at]/sigma^2)*(X[t,att]-phi*X[t-1,at])
    alphas[8,] = (-1/sigma + (1/sigma^3)*(X[t,att]-phi*X[t-1,at])^2)
    
            Sn[t,] = Sn[t-1,] + weights[kk,]%*%t(alphas)        #Score at time t
}
      ctime = proc.time()[3]  #End time
  cat(" Total time elapsed: ", round((ctime-itime)/60,2),"\n") #Print run time
    return(list(logl=logl,score=Sn[T,]))
}

#################################################################


