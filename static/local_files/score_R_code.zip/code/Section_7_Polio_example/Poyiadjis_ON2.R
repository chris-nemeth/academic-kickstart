#This file contains the code for parameter estimation using the example from Section 7.2 of the paper.
# The Poyiadjis O(N^2) algorithm is used to estimate the score
#######################################################################
# Nonlinear seasonal Poisson SSM
#
# X_1 ~ N(0,sigma2/(1-phi^2))
# X_n+1 = phi*X_n + sigma*V_n
# beta_n = mu1+mu2*(t/1000)+mu3*cos(2*pi*t/12)+mu4*sin(2*pi*t/12)+mu5*cos(2*pi*t/6)+mu6*sin(2*pi*t/6)
# Y_n = Pois(beta_n*exp(X_n))
#
#############################################################
#Particle filter to calculate the score

PF = function(Y,theta,N){
    #Y is the data
    #theta is a vector of model parameters
    #N is the number of particles

    itime  = proc.time()[3]                               #Start time
    mu1 = theta[1];  mu2 = theta[2]; mu3 = theta[3]; mu4 = theta[4]; mu5 = theta[5]; mu6 = theta[6]; phi = theta[7];  sigma = theta[8];
    T  = length(Y)                                        #Time
    X  =  rnorm(N,0,sqrt(sigma^2/(1-phi^2)))             #Initialise particles from stationary distribution
    beta = mu1 + mu2*(1/1000) + mu3*cos(2*pi/12) + mu4*sin(2*pi/12) + mu5*cos(2*pi/6)+mu6*sin(2*pi/6) #seasonal component
    w1 = dpois(Y[1],exp(beta+X))
    logl = log(mean(w1))
    w1 = w1/sum(w1)
    alphas = matrix(0,nrow=8,ncol=N)                       # dlog(p(x_1:T,y_1:T))
    Sn = matrix(0,nrow=T,ncol=8)                          # dlog(p(y_1:T))
    alphas[1,] = Y[1]-exp(beta+X)
    alphas[2,] = (1/1000)*(Y[1]-exp(beta+X))
    alphas[3,] = cos(2*pi*1/12)*(Y[1]-exp(beta+X))
    alphas[4,] = sin(2*pi*1/12)*(Y[1]-exp(beta+X))
    alphas[5,] = cos(2*pi*1/6)*(Y[1]-exp(beta+X))
    alphas[6,] = sin(2*pi*1/6)*(Y[1]-exp(beta+X))
    alphas[7,] = (X^2*phi/sigma^2-phi/(1-phi^2))
    alphas[8,] = ((X^2)*(1-phi^2)/sigma^3-1/sigma)
    Sn[1,] = w1%*%t(alphas)                              #Estimate the score at t=1
    for (t in 2:T){
        #Apply approximate auxiliary filter where p(y_t|x_{t-1}) = p(y_t|E[x_{t-1}]). See Pitt and Shephard 1999
    # Resampling
   beta = mu1 + mu2*(t/1000) + mu3*cos(2*pi*t/12) + mu4*sin(2*pi*t/12) + mu5*cos(2*pi*t/6) + mu6*sin(2*pi*t/6)
    w0          = dpois(Y[t],exp(beta+phi*X))   #p(y_t|x_t-1)
    weights     = w1*w0
    weights     = weights/sum(weights)
    k           = sample(1:N,size=N,replace=T,prob=weights)   #Resample
    X1          = X
    # Propagating states
    X        = rnorm(N,phi*X1[k],sigma)
    w1       = w1[k]*dpois(Y[t],exp(beta+X))/weights[k]   #p(y_t|x_t)
    logl     = logl + log(mean(w1))                       #estimate the log-likelihood
    w1       = w1/sum(w1)                                   #Normalise weights
    
        #Calculate w[t]f_theta(X[t]|X[t-1])
    xtemp=rep(X,N);x1temp=rep(phi*X1,N)
    wf=matrix(X,nr=N,nc=N,byrow=F)-matrix(phi*X1,nr=N,nc=N,byrow=T) ##first X-phi*X1
    wf=exp(-0.5*wf^2/sigma^2)/sqrt(2*pi*sigma^2)
    sum_f=apply(wf,1,sum)

    #Estimate the gradient of joint distribution
    alphas.n=alphas
    alphas.n[1,] = sapply(1:N,function(i) sum(wf[i,]*(alphas[1,] + Y[t]-exp(beta+X[i])))/sum_f[i])
    alphas.n[2,] = sapply(1:N,function(i) sum(wf[i,]*(alphas[2,] + (t/1000)*(Y[t]-exp(beta+X[i]))))/sum_f[i])
    alphas.n[3,] = sapply(1:N,function(i) sum(wf[i,]*(alphas[3,] + cos(2*pi*t/12)*(Y[t]-exp(beta+X[i]))))/sum_f[i])
    alphas.n[4,] = sapply(1:N,function(i) sum(wf[i,]*(alphas[4,] + sin(2*pi*t/12)*(Y[t]-exp(beta+X[i]))))/sum_f[i])
    alphas.n[5,] = sapply(1:N,function(i) sum(wf[i,]*(alphas[5,] + cos(2*pi*t/6)*(Y[t]-exp(beta+X[i]))))/sum_f[i])
    alphas.n[6,] = sapply(1:N,function(i) sum(wf[i,]*(alphas[6,] + sin(2*pi*t/6)*(Y[t]-exp(beta+X[i]))))/sum_f[i])
    alphas.n[7,] = sapply(1:N,function(i) sum(wf[i,]*(alphas[7,] + (X1/sigma^2)*(X[i]-phi*X1)))/sum_f[i])
    alphas.n[8,] = sapply(1:N,function(i) sum(wf[i,]*(alphas[8,] +(-1/sigma + (1/sigma^3)*(X[i]-phi*X1)^2)))/sum_f[i])
        alphas = alphas.n
       #Score at time t
    Sn[t,] = w1%*%t(alphas)
  }
      ctime = proc.time()[3]  #End time
  cat(" Total time elapsed: ", round((ctime-itime)/60,2),"\n") #Print run time
    return(list(logl=logl,score=Sn[T,]))
}

#################################################################

