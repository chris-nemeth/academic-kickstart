#This file contains the code for parameter estimation using the example from Section 7.2 of the paper.
#######################################################################
# Nonlinear seasonal Poisson SSM
#
# X_1 ~ N(0,sigma2/(1-phi^2))
# X_n+1 = phi*X_n + sigma*V_n
# beta_n = mu1+mu2*(t/1000)+mu3*cos(2*pi*t/12)+mu4*sin(2*pi*t/12)+mu5*cos(2*pi*t/6)+mu6*sin(2*pi*t/6)
# Y_n = Pois(beta_n*exp(X_n))
#
#############################################################
rm(list=ls())
library(acp)
data(polio)
##############################################################
source("Our_algorithm.R") #Load particle filter code. This can be replaced with Fixed-lag and O(N^2), but note that you need to change the arguments in PF(...) 

#Batch Parameter Estimation

N = 2000         #Number of particles
NumIt = 2000     #Number of iterations
parEst = matrix(0,NumIt,8) #store parameter estimates

Y = polio$polio            #data
T = length(Y)              #length of data

theta = c(0.4,-3,0.3,-0.3,0.65,-0.2,0.4,sqrt(0.4))   #starting value
parEst[1,] = theta
for(k in 2:NumIt){
G2 =  PF(Y,theta,N,0.95)                                        #Run particle filter
   par = theta + (k-1)^(-2/3)*G2$score/T*c(1,T,1,1,1,1,1,1) #Note we scale the gradient components as (1,T,1,1,1,1,1,1) to give better convergence
theta[1:6] = par[1:6]
#Note: parameters could be reparameterised to avoid constraints.
if(par[7]>0 && par[7]<1){theta[7]=par[7]} #ensure phi is between 0 and 1
if(par[8]>0){theta[8]=par[8]}             #ensure positive variance
parEst[k,] = theta                        #Store parameter estimate
cat("It:",k,"Logl:",G2$logl,"\n")
print(parEst[k,])                           #Prints parameters
}





